1 ) when application loads the default feature component should be coupon code (a_Coupons_defaultPage): 

   a_Coupons_defaultPage:options 

         - allows to click button to save coupon
         - exit - > leads to the store component

2 ) Store Component changed view as in (b_adding route to product description) 

    b_adding route to product description:options 

        - product description click leads to loading another feature component as described in file 
          (c_product description_relatedItems_addToCart) 

          c_product description_relatedItems_addToCart:options 

             - Select related items should lead to its description similar to 
               (b_adding route to product description)

             - add product to cart should lead the route to "cartDetail component"

 3 ) cartDetail Component:options 

      - apply coupon leads to discounted rates as seen in file (e_cartDetail_after_applyCoupon)

  please submit your assignments to mukesh.trainings@gmail.com before the coming friday. 

  




